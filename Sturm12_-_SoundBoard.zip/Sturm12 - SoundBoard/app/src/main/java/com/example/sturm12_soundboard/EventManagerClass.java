package com.example.sturm12_soundboard;

import android.media.MediaPlayer;
import android.util.Log;
import android.view.View;
import android.widget.PopupMenu;

public class EventManagerClass {

    private static final String LOG_TAG = "EventManager";

    private static MediaPlayer mp;

    public static void startMediaPlayer(View view, Integer soundID){

        try{

            if (soundID != null){

                if (mp != null){

                    mp.reset();
                }

                mp = MediaPlayer.create(view.getContext(), soundID);
                mp.start();

            }

        } catch (Exception e){

            Log.e(LOG_TAG, "Fehler beim Starten des MediaPlayer:" + e.getMessage());
        }
    }

    public static void releaseMediaPlayer(){

        if (mp != null){

            mp.release();
            mp = null;
        }
    }

    public static void popupManager(final View view, final SoundObject soundObject){

        PopupMenu popup = new PopupMenu(view.getContext(), view);
        popup.getMenuInflater().inflate(R.menu.longclick, popup.getMenu());

        popup.show();
    }

}
