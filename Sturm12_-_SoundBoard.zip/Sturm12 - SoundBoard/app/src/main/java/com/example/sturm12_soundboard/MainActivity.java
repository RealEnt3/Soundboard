package com.example.sturm12_soundboard;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ArrayList<SoundObject> soundlist  = new ArrayList<>();

    RecyclerView SoundView;
    SoundboardRecyclerAdapter SoundAdapter = new SoundboardRecyclerAdapter(soundlist);
    RecyclerView.LayoutManager SoundLayoutManager;


     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         List<String> nameList = Arrays.asList(getResources().getStringArray(R.array.soundNames));

        SoundObject[] soundItems = {new SoundObject(nameList.get(0), R.raw.airhorn), new SoundObject(nameList.get(1), R.raw.mr_krabs_im_krankenhaus), new SoundObject(nameList.get(2), R.raw.patrick_dumme_leute), new SoundObject(nameList.get(3), R.raw.patrick_bester_freund), new SoundObject(nameList.get(4), R.raw.spongebob_lache), new SoundObject(nameList.get(5), R.raw.spongebob_titelmusik)};

        soundlist.addAll(Arrays.asList(soundItems));

        SoundView = (RecyclerView) findViewById(R.id.soundboardRecyclerView);

        SoundLayoutManager = new GridLayoutManager(this, 3);

        SoundView.setLayoutManager(SoundLayoutManager);

        SoundView.setAdapter(SoundAdapter);
    }

    @Override
    protected void onDestroy(){
         super.onDestroy();

         EventManagerClass.releaseMediaPlayer();
    }
}
